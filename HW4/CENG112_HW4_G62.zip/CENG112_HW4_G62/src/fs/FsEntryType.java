package fs;

public enum FsEntryType {
	DIR,
	REGFILE;
}
